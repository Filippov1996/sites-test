
import React, { Fragment, Component } from "react";
import 'bootstrap/dist/css/bootstrap.min.css';
import Header from "./Header";
import Nav from "./Nav";
import Posts from "./Posts";
//import Test from "./Test";
import Footer from "./Footer";
import Message from "./Content";
class App extends Component {
    render(){
        const header_data={
          logo:"http://site-portfolio.online/level-estate/wp-content/uploads/2026/01/logo-header.svg",
          name:"Level Estate"
        };
        const navdata =[
          {
            title:"About",
            link:"/about"
          },
          {
            title:"News",
            link:"/news"
          },
          {
            title:"Gallery",
            link:"/gallery"
          },
          {
            title:"Contact",
            link:"/contact"
          }
        ];
        const posts =[
            {
              title:'Post1',
              description:"Lorem ipsum dolor sit amet consectetur adipisicing elit. Necessitatibus dolor inventore id eos expedita recusandae illum optio voluptates nobis saepe eum repellendus rem ut numquam eius nam rerum, non aut."
            },
             {
              title:'Post2',
              description:"Lorem ipsum dolor sit amet consectetur adipisicing elit. Necessitatibus dolor inventore id eos expedita recusandae illum optio voluptates nobis saepe eum repellendus rem ut numquam eius nam rerum, non aut."
            }
        ];
        const footerdata = new Date().getFullYear();
        return(
          <Fragment>
            <Header {...header_data}/>
             <Nav menu={navdata}/>
             <Posts posts={posts}></Posts>
             <Message status msg="Данные обработаны"/>
             <Footer year={footerdata}/>
            </Fragment>
        )
    } 
}

export default App;
