import React, {Component } from "react";

class Test extends Component{
    render(){
        return(
            <select> 
            {this.props.items.map((item) => ( 
            <option key={item.title}>{item.title}</option> 
            ))} 
            </select>
        );
    }
}
export default Test;