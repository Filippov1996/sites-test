
import React, { Fragment, Component } from "react";
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
/*class Menu extends Component{
    render(){
        return(
            <nav className="nav">
              <div className="container nav__wrapp">
              <a className="nav__logo" href="/">{this..name}</a>
              <ul className="nav__menu">
                  <MenuItem url="/about" label="About"></MenuItem>
                  <MenuItem url="/gallery" label="Gallery"></MenuItem>
                  <MenuItem url="/contact" label="Contact"></MenuItem>
              </ul>
              </div>
            </nav>
        )
    }
}
class MenuItem extends Component{
    render(){
      return(<li className="nav__menu-item"><a href={this..url}>{this..label}</a></li>)
    }

}

class App extends Component {
    render(){
  
        return(
          <Menu name="Test logo"></Menu>
        )
    } 
}*/
const Menu = ({name})=>{
        return(
            <nav className="nav">
              <div className="container nav__wrapp">
              <a className="nav__logo" href="/">{name}</a>
              <ul className="nav__menu">
                  <MenuItem url="/about" label="About"></MenuItem>
                  <MenuItem url="/gallery" label="Gallery"></MenuItem>
                  <MenuItem url="/contact" label="Contact"></MenuItem>
              </ul>
              </div>
            </nav>
        )
}
const MenuItem = ({url,label})=>{
        return(<li className="nav__menu-item"><a href={url}>{label}</a></li>)
}
function App(){
          return(
            <Menu name="Test logo"></Menu>
        );
}

export default App;
